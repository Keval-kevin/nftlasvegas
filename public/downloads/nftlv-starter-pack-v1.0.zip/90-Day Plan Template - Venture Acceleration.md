
# 90-Day Plan — Venture Acceleration (Template)

## Company
Name:  
Point of Contact:  
Email / Phone:  

## Goals (Top 3 Outcomes)
1. 
2. 
3. 

## Success Metrics (KPIs)
- Pipeline/Revenue:
- Product/Tech:
- Marketing/GTM:
- Ops/Cost:

## Constraints / Risks
- 
- 

---

## 30 Days — Foundation
**Objectives:** Discovery, Access, Roadmap, Sprint 0  
**Key Deliverables:**
- Stakeholder map, KPIs, tool access
- Current-state audit, opportunity analysis
- 90-day plan, backlog, architecture
- Design proofs/wireframes

**Milestones:**
- 
**Owner(s):** 

## 60 Days — Build & Pilot
**Objectives:** MVP build, integrations, content ops, analytics v1  
**Key Deliverables:**
- MVP/features, CRM + automation workflows
- Pilot program and QA checklist
- KPI dashboard v1

**Milestones:**
- 
**Owner(s):** 

## 90 Days — Launch & Scale
**Objectives:** Launch, distribution, iteration plan  
**Key Deliverables:**
- Launch playbook and calendar
- Channel/partner enablement kit
- Performance report and next-quarter plan

**Milestones:**
- 
**Owner(s):** 

---

## Roles & Cadence
- Executive Sponsor: 
- Product Owner: 
- Program Manager: 
- Engineering Lead: 
- Marketing Lead: 
- Design Lead: 

Standups (Weekly) • Steering (Biweekly) • KPI Review (Monthly)

## Dependencies & Access
- Repos/Hosting:
- CRM/Analytics:
- Telephony/Integrations:
- Compliance/Legal:

## Budget & Timeline
- Budget Band: 
- Timeline: 
- Billing Contact: 
