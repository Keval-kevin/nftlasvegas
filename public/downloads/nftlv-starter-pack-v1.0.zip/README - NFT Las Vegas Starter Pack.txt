NFT Las Vegas™ — Starter Pack (v1.0)
Generated: Oct 04, 2025

Included files:
1) NFT Las Vegas — Onboarding Guide v1.0.pdf
2) AI Voice System — Kickoff Checklist v1.0.pdf
3) 90-Day Plan Template - Venture Acceleration.md

How to use:
- Start with the Onboarding Guide (overview of 6-step pathway, access checklist).
- If you’re exploring AI Voice Agents, use the Kickoff Checklist.
- Copy the 90-Day Plan template into your workspace (Notion/Doc) and fill it out with your team.
- When you’re ready, book a Discovery Call with NFT Las Vegas™.
